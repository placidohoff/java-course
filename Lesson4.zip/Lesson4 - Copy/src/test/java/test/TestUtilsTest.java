package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestUtilsTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testAdd() {
//		System.out.println("The test ran");
		TestUtils test = new TestUtils();
		int expected = 2;
		int actual = test.add(1, 1);
		assertEquals(expected, actual, "The add method should add two numbers");
	}
	
	@Test
	void testDivide() {
		TestUtils test = new TestUtils();
		assertThrows(ArithmeticException.class, () -> test.divide(1, 0), "Divide by zero should throw an exception");

	}
	
	@Test
	void testComputeCircleRadius() {
		TestUtils test = new TestUtils();
		assertEquals(314.1592653589793, test.computeCircleArea(10), "Should return the area of . . .");
	}
	
	

}
