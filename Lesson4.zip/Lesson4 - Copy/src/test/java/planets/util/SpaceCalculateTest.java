package planets.util;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import planets.bodies.Planet;
import planets.bodies.PlanetaryBody;
import planets.transportation.AirCraft;
import planets.transportation.TransportationVehicle;
import planets.bodies.PlanetaryBody;
public class SpaceCalculateTest {
	String[] planet1Details = {"1",	"Mercury",	"Planet",	"Sun",	"4880","1408","88","0","3.7","-173","427",	"167",	"0",	"Thin atmosphere, mostly oxygen, sodium, and hydrogen.",	"Being the closest planet to the Sun.",	"Negligible",	"Terrestrial",	"0.2056",	"0.106",	"0.055000",	"91690000",	"57909227",	"77000000",	"46001200",	"217000000",	"69816900",	"Smallest planet in the solar system, heavily cratered.",	"One day on Mercury lasts longer than one year.",	"Given its proximity to the Sun, Mercury is difficult to study from Earth."
};
	String[] planet2Details = {
		    "3", // ID
		    "Earth", // Name
		    "Planet", // Type
		    "Sun", // Parent Body
		    "12742", // Diameter (km)
		    "24", // Hours in a day
		    "365.25", // Days in a year
		    "1", // Moons
		    "9.8", // Gravity (m/s^2)
		    "-89", // Minimum Temperature (°C)
		    "58", // Maximum Temperature (°C)
		    "14", // Atmospheric Pressure (psi)
		    "0", // Magnetic Field
		    "78% Nitrogen, 21% Oxygen, 1% other gases (mostly Argon).", // Composition
		    "Being the only known planet with life.", // Description
		    "1", // Rings
		    "Terrestrial", // Classification
		    "0.0167", // Orbital Eccentricity
		    "0.3", // Orbital Inclination (°)
		    "1.000000", // Axial Tilt (°)
		    "0", // Perihelion Distance (km)
		    "149597870.7", // Semi-Major Axis (km)
		    "0", // Aphelion Distance (km)
		    "147095000", // Perihelion (km)
		    "0", // Aphelion (km)
		    "152100000", // Mean Distance (km)
		    "Earth has diverse weather patterns and a rich variety of life forms.", // Additional Info 1
		    "Earth is the only planet in our solar system with liquid water on its surface.", // Additional Info 2
		    "Human activities are impacting the climate and ecosystems." // Additional Info 3
		};
	
	String[] testTransportVehicleData = {
		    "3", // Index
		    "Space Shuttle", // Transport Vehicle Name
		    "Spacecraft", // Classification
		    "2030000", // Maximum Weight (kg)
		    "350", // Volume (m^3)
		    "1500000000", // Cost to Build (USD)
		    "28160", // Max speed km/h
		    "8", // Number of crew members
		    "37.24m x 23.79m x 17.56m", // Measurements (metric)
		    "10", // Per meal food cost per crew member ($)
		    "300", // Hourly salary per crew member ($)
		    "Part of NASA's Space Shuttle program, used for Earth-to-orbit crew and cargo transport.", // Description
		    "The Space Shuttle had 135 missions from 1981 to 2011.", // Interesting fact
		    "Food and salary costs are estimations." // Notes
		};

    @Test
    public void testFindOrbitalVelocity() {
        double result = SpaceCalculate.findOrbitalVelocity(1.0, 365);
        assertEquals(29.78503903272441, result, 0.001);
    }

    @Test
    public void testApplyGravityAssist() {
        double result = SpaceCalculate.applyGravityAssist();
        assertEquals(0, result); // The method doesn't have any logic, just returns 2 * orbitalVelocity
    }

    @Test
    public void testCalculateJourneyHours() {
        double result = SpaceCalculate.calculateJourneyHours("Earth", "Mars", "Space Shuttle");
        assertEquals(175.84, result, 0.01);
    }

    @Test
    public void testFindGravityAssist() {
        double result = SpaceCalculate.findGravityAssist();
        assertEquals(0, result); // The method doesn't have any logic, just returns 2 * orbitalVelocity
    }

    @Test
    public void testFindDistanceBetween() {
        PlanetaryBody start = new Planet(planet1Details);
        PlanetaryBody finish = new Planet(planet2Details);
        double result = SpaceCalculate.findDistanceBetween(start, finish);
        assertEquals(0.5, result);
    }

    @Test
    public void testFindTravelTime() {
        // Assuming currentVehicleVelocity is set to 1 mile per hour
        double currentVehicleVelocity = 1.0;
        
        // Assuming CONVERSION_FACTOR_KILOMETERS_TO_MILES is set to 0.621371 (1 km = 0.621371 miles)
        double result = SpaceCalculate.findTravelTime(1.0);

        // Calculate the expected result manually based on the formula distance / velocity
        // Since the distance is 1 mile and the velocity is 1 mile per hour, the expected result should be 1 hour.
        assertEquals(1.0, result, 0.001); // 0.001 is the delta for double comparison
    }
    
    @Test
    public void testGetTimeFormattedAsString() {
        String result = SpaceCalculate.getTimeFormattedAsString(8761);
        assertEquals("1.0 years", result);
    }
    
    @Test
    public void testLessThanOneDay() {
        assertEquals("2.0 hours", SpaceCalculate.getTimeFormattedAsString(2));
        assertEquals("6.5 hours", SpaceCalculate.getTimeFormattedAsString(6.5));
    }

    @Test
    public void testOneDayToLessThanOneYear() {
        assertEquals("1.5 days", SpaceCalculate.getTimeFormattedAsString(36));
        assertEquals("300.5 days", SpaceCalculate.getTimeFormattedAsString(7212));
    }

    @Test
    public void testMoreThanOneYear() {
        assertEquals("1.5 years", SpaceCalculate.getTimeFormattedAsString(13176));
        assertEquals("8.0 years", SpaceCalculate.getTimeFormattedAsString(70080));
    }
 // Test cases for getters:

    @Test
    public void testGetDaysPerYear() {
        assertEquals(365, SpaceCalculate.getDaysPerYear());
    }

    @Test
    public void testGetHoursPerDay() {
        assertEquals(24, SpaceCalculate.getHoursPerDay());
    }

    @Test
    public void testGetConversionKilogramsToPounds() {
        assertEquals(2.2046, SpaceCalculate.getConversionKilogramsToPounds());
    }

    @Test
    public void testGetConversionPoundsToKilograms() {
        assertEquals(0.4536, SpaceCalculate.getConversionPoundsToKilograms());
    }

    @Test
    public void testGetConversionKilometersToMiles() {
        assertEquals(0.6214, SpaceCalculate.getConversionKilometersToMiles());
    }

    @Test
    public void testGetConversionMilesToKilometer() {
        assertEquals(1.6093, SpaceCalculate.getConversionMilesToKilometer());
    }



//    @Test
//    public void testCalculateJourneyExpenses() {
//        String[] result = SpaceCalculate.calculateJourneyExpenses(testTransportVehicle);
//        assertEquals(8, result.length); // Assuming this number of elements is returned
//    }
    
    @Test
    public void testCalculateFoodExpenses() {

    	TransportationVehicle mockVehicle = new AirCraft(testTransportVehicleData);

        // Set the number of crew members and total trip duration
        int numberOfCrewMembers = 5;
        int totalTripDurationDays = 7;

        // Calculate the expected food expenses
        double expectedExpenses = numberOfCrewMembers * mockVehicle.getDailyFoodCostPerCrewMember()
                * totalTripDurationDays * mockVehicle.getMealsPerDay();

        // Call the method under test
        double actualExpenses = SpaceCalculate.calculateFoodExpenses(mockVehicle);

        // Assert that the calculated expenses match the expected expenses
        assertEquals(expectedExpenses, actualExpenses, 0.001); // Using delta for double comparison
    }
}
