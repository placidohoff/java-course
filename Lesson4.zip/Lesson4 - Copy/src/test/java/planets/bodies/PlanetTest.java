package planets.bodies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlanetTest {

	private final String[] earthData = {"1", "Earth", "Planet", "Sun", "12742", "24", "365.25", "1", "9.8", "-89", "58", "14", "0", "78% Nitrogen, 21% Oxygen, 1% other gases (mostly Argon).", "Being the only known planet with life.", "1", "Terrestrial", "0.0167", "0.3", "1.000000", "0", "149597870.7", "0", "147095000", "0", "152100000", "Earth has diverse weather patterns and a rich variety of life forms.", "Earth is the only planet in our solar system with liquid water on its surface.", "Human activities are impacting the climate and ecosystems."};

    @Test
    public void testGetElementName() {
        Planet earth = new Planet(earthData);
        assertEquals("Earth", earth.getElementName());
    }

    @Test
    public void testGetDragCoefficient() {
        Planet earth = new Planet(earthData);
        assertEquals(0.1 + (0.3 * 0.0167), earth.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testToString() {
        Planet earth = new Planet(earthData);
        assertEquals("Earth", earth.toString());
    }

}
