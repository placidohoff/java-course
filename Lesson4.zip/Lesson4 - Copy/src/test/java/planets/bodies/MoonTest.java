package planets.bodies;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MoonTest {

    private final String[] lunaData = {"1", "Luna", "Moon", "Earth", "3474.8", "708.7", "354", "0", "1.625", "-233", "123", "-23", "0", "Very thin exosphere (helium, neon, hydrogen)", "Earth's only natural satellite is simply called \"the Moon\" because people didn't know other moons existed until Galileo Galilei discovered four moons orbiting Jupiter in 1610. In Latin, the Moon was called Luna, which is the main adjective for all things Moon-related: lunar.", "Near vacuum", "Rocky satellite", "0.0554", "0.11", "0.012300", "384400", "149597870.7", "363104", "147095000", "405696", "152100000", "The Moon is Earth's only natural satellite and plays a significant role in causing tides on our planet.", "Its surface bears witness to intense asteroid bombardment.", "The far side of the Moon was first observed by humans in 1959 when the Soviet Luna 3 spacecraft returned the first images."};

    @Test
    public void testGetElementName() {
        Moon luna = new Moon(lunaData);
        assertEquals("Luna", luna.getElementName());
    }

    @Test
    public void testGetDragCoefficient() {
        Moon luna = new Moon(lunaData);
        assertEquals(0.75 + (0.11 * 0.0554), luna.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testToString() {
        Moon luna = new Moon(lunaData);
        assertEquals("Luna", luna.toString());
    }
}