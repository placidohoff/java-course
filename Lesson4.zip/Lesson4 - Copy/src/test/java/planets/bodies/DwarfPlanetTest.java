package planets.bodies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

 class DwarfPlanetTest {

    private final String[] haumeaData = {"1", "Haumea", "Dwarf planet", "Sun", "1630", "3.9", "104283", "2", "0.44", "-241", "-211", "-226", "1", "Possibly methane and nitrogen ice.", "Its elongated shape and fast rotation.", "Unknown", "Icy dwarf", "0.19126", "0.7", "0.000700", "6500000000", "6471000000", "6355000000", "6214200000", "6800000000", "6728550000", "Known for its unique elongated shape.", "Haumea has two known moons: Hi'iaka and Namaka.", "One of the fastest rotating large objects in our solar system."};

    @Test
    public void testGetElementName() {
        DwarfPlanet haumea = new DwarfPlanet(haumeaData);
        assertEquals("Haumea", haumea.getElementName());
    }

    @Test
    public void testGetDragCoefficient() {
        DwarfPlanet haumea = new DwarfPlanet(haumeaData);
        assertEquals(0.35 + (0.7 * 0.44), haumea.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testToString() {
        DwarfPlanet haumea = new DwarfPlanet(haumeaData);
        assertEquals("Haumea", haumea.toString());
    }
}

