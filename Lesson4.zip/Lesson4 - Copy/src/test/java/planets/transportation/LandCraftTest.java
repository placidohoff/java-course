package planets.transportation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LandCraftTest {

	private final String[] mercedesData = {"1", "Mercedes-Benz GLE", "Car", "2420", "4.8", "60000", "209", "1", "493cm x 195cm x 180cm", "15", "100", "A series of midsize luxury SUVs produced by the German automaker Mercedes-Benz.", "The GLE is one of the best-selling SUVs in the Mercedes lineup.", "Specs and price might vary based on model, year, and region."};

    @Test
    public void testGetElementName() {
        LandCraft mercedes = new LandCraft(mercedesData);
        assertEquals("Mercedes-Benz GLE", mercedes.getElementName());
    }

    @Test
    public void testToString() {
        LandCraft mercedes = new LandCraft(mercedesData);
        assertEquals("Mercedes-Benz GLE", mercedes.toString());
    }

    @Test
    public void testGetDragCoefficient() {
        LandCraft mercedes = new LandCraft(mercedesData);
        assertEquals(0.0744, mercedes.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testGetMealsPerDay() {
        LandCraft mercedes = new LandCraft(mercedesData);
        assertEquals(5, mercedes.getMealsPerDay(), 0.0001);
    }

    @Test
    public void testGetPayHoursPerDay() {
        LandCraft mercedes = new LandCraft(mercedesData);
        assertEquals(12, mercedes.getPayHoursPerDay(), 0.0001);
    }

}
