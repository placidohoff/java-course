package planets.transportation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SeaCraftTest {

    private final String[] spiritOfAustraliaData = {"1","Spirit of Australia wooden speedboat", "Boat", "500", "2", "50000", "513.11", "1", "8.22 m × 2.37 m", "20", "150", "A wooden hydroplane speedboat which holds the world water speed record.", "Set the world record in 1978, which still stands today.", "Exact specs are not widely available."};

    @Test
    public void testGetElementName() {
        SeaCraft spiritOfAustralia = new SeaCraft(spiritOfAustraliaData);
        assertEquals("Spirit of Australia wooden speedboat", spiritOfAustralia.getElementName());
    }

    @Test
    public void testToString() {
        SeaCraft spiritOfAustralia = new SeaCraft(spiritOfAustraliaData);
        assertEquals("Spirit of Australia wooden speedboat", spiritOfAustralia.toString());
    }

    @Test
    public void testGetDragCoefficient() {
        SeaCraft spiritOfAustralia = new SeaCraft(spiritOfAustraliaData);
        assertEquals(0.0744, spiritOfAustralia.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testGetMealsPerDay() {
        SeaCraft spiritOfAustralia = new SeaCraft(spiritOfAustraliaData);
        assertEquals(8, spiritOfAustralia.getMealsPerDay(), 0.0001);
    }

    @Test
    public void testGetPayHoursPerDay() {
        SeaCraft spiritOfAustralia = new SeaCraft(spiritOfAustraliaData);
        assertEquals(16, spiritOfAustralia.getPayHoursPerDay(), 0.0001);
    }

}
