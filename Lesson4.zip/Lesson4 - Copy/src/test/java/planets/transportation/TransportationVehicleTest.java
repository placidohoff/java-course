package planets.transportation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TransportationVehicleTest {

	 private final String[] vehicleData = {"1", "Space Shuttle", "Spacecraft", "2030000", "350", "1500000000", "28160", "8", "37.24m x 23.79m x 17.56m", "10", "300", "Part of NASA's Space Shuttle program, used for Earth-to-orbit crew and cargo transport.", "The Space Shuttle had 135 missions from 1981 to 2011.", "Food and salary costs are estimations."};

	 @Test
	 public void testGetElementName() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("Space Shuttle", vehicle.getElementName());
	 }

	 @Test
	 public void testToString() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("Space Shuttle", vehicle.toString());
	 }

	 @Test
	 public void testGetMaximumWeight() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(2030000, vehicle.getMaximumWeight(), 0.0001);
	 }

	 @Test
	 public void testGetVolume() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(350, vehicle.getVolume(), 0.0001);
	 }

	 @Test
	 public void testGetCostToBuild() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(1500000000, vehicle.getCostToBuild(), 0.0001);
	 }

	 @Test
	 public void testGetMaxSpeed() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(28160, vehicle.getMaxSpeed(), 0.0001);
	 }

	 @Test
	 public void testGetNumberOfCrew() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(8, vehicle.getNumberOfCrew(), 0.0001);
	 }

	 @Test
	 public void testGetMetricMeasurementsDescription() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("37.24m x 23.79m x 17.56m", vehicle.getMetricMeasurementsDescription());
	 }

	 @Test
	 public void testGetMealCostPerCrewMember() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(10, vehicle.getMealCostPerCrewMember(), 0.0001);
	 }

	 @Test
	 public void testGetHourlySalaryPerCrewMember() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals(300, vehicle.getHourlySalaryPerCrewMember(), 0.0001);
	 }

	 @Test
	 public void testGetDescription() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("Part of NASA's Space Shuttle program, used for Earth-to-orbit crew and cargo transport.", vehicle.getDescription());
	 }

	 @Test
	 public void testGetInterestingFact() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("The Space Shuttle had 135 missions from 1981 to 2011.", vehicle.getInterestingFact());
	 }

	 @Test
	 public void testGetNotes() {
	     TransportationVehicle vehicle = new AirCraft(vehicleData);
	     assertEquals("Food and salary costs are estimations.", vehicle.getNotes());
	 }
	 }
