package planets.transportation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AirCraftTest {

	  private final String[] spaceShuttleData = {"1", "Space Shuttle", "Spacecraft", "2030000", "350", "1500000000", "28160", "8", "37.24m x 23.79m x 17.56m", "10", "300", "Part of NASA's Space Shuttle program, used for Earth-to-orbit crew and cargo transport.", "The Space Shuttle had 135 missions from 1981 to 2011.", "Food and salary costs are estimations."};

	    @Test
	    public void testGetElementName() {
	        AirCraft spaceShuttle = new AirCraft(spaceShuttleData);
	        assertEquals("Space Shuttle", spaceShuttle.getElementName());
	    }

	    @Test
	    public void testToString() {
	        AirCraft spaceShuttle = new AirCraft(spaceShuttleData);
	        assertEquals("Space Shuttle", spaceShuttle.toString());
	    }

	    @Test
	    public void testGetDragCoefficient() {
	        AirCraft spaceShuttle = new AirCraft(spaceShuttleData);
	        assertEquals(0.0102, spaceShuttle.getDragCoeficient(), 0.0001);
	    }

	    @Test
	    public void testGetMealsPerDay() {
	        AirCraft spaceShuttle = new AirCraft(spaceShuttleData);
	        assertEquals(3.5, spaceShuttle.getMealsPerDay(), 0.0001);
	    }

	    @Test
	    public void testGetPayHoursPerDay() {
	        AirCraft spaceShuttle = new AirCraft(spaceShuttleData);
	        assertEquals(24, spaceShuttle.getPayHoursPerDay(), 0.0001);
	    }

}
