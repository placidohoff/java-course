package planets.transportation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SpacecraftTest {

	private final String[] enterpriseData = {"1", "USS Enterprise NCC-1701", "Starship", "190000000", "5940000", "1240000000000", "268760448", "430", "288m x 127m x 59m", "10", "200", "Fictional starship from the Star Trek universe.", "The USS Enterprise is an iconic ship in the Star Trek series.", "All values are fictional or estimates based on the Star Trek universe. Maximum speed is Warp 8.  Warp factor 8 equals the cube of 8 (8 times 8 times 8), or 512 times light speed.  The Star Trek Voyager Technical Manual, page 13, has full impulse listed as ¼ of the speed of light, which is 167,000,000 mph or 74,770 km/s."};

    @Test
    public void testGetElementName() {
        Spacecraft enterprise = new Spacecraft(enterpriseData);
        assertEquals("USS Enterprise NCC-1701", enterprise.getElementName());
    }

    @Test
    public void testToString() {
        Spacecraft enterprise = new Spacecraft(enterpriseData);
        assertEquals("USS Enterprise NCC-1701", enterprise.toString());
    }

    @Test
    public void testGetDragCoefficient() {
        Spacecraft enterprise = new Spacecraft(enterpriseData);
        assertEquals(0, enterprise.getDragCoeficient(), 0.0001);
    }

    @Test
    public void testGetMealsPerDay() {
        Spacecraft enterprise = new Spacecraft(enterpriseData);
        assertEquals(3.5, enterprise.getMealsPerDay(), 0.0001);
    }

    @Test
    public void testGetPayHoursPerDay() {
        Spacecraft enterprise = new Spacecraft(enterpriseData);
        assertEquals(24, enterprise.getPayHoursPerDay(), 0.0001);
    }
}
