/**
 * 
 */
package test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 */
public class PoiReadExcelTest {
	
	private static final Logger logger = LogManager.getLogger(PoiReadExcelTest.class.getName());
	
	private static final String INPUT_FILE_NAME = "src/main/resources/lesson02/example/in/Planets.xlsx";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		PoiReadExcel poiReadExcel = new PoiReadExcel(INPUT_FILE_NAME);
		logger.debug("Testing....");

	}

}
