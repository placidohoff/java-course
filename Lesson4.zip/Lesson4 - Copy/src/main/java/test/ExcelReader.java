package test;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelReader {

    public static void main(String[] args) {
        try {
            // Load Excel file
            FileInputStream file = new FileInputStream(new File("src/main/resources/lesson02/example/in/Planets.xlsx"));
            Workbook workbook = WorkbookFactory.create(file);

            // Get the first sheet (Planet_details)
            Sheet sheet1 = workbook.getSheetAt(0);
            
            List<String[]> data = new ArrayList();

            // Iterate through rows
            for (int i = 1; i <= sheet1.getLastRowNum(); i++) { // Start from 1 to skip the header row
                Row row = sheet1.getRow(i);
                String[] rowData = new String[row.getLastCellNum()];

                // Iterate through cells
                for (int j = 0; j < row.getLastCellNum(); j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    cell.setCellType(CellType.STRING); // Ensure all cells are treated as strings
                    rowData[j] = cell.getStringCellValue();
                }

                data.add(rowData); // Add row data to the list
            }

            // Print the extracted data
            for (String[] rowData : data) {
                for (String cellData : rowData) {
                    System.out.print(cellData + "\t");
                }
                System.out.println();
            }

            workbook.close();
            file.close();

                    } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
