/**
 * Specifies the common operations for accessing data.
 */
package assignment.data;

import java.util.List;

/**
 * Represents operations for accessing data.
 */
public interface DataAccessOperations {
    
    /**
     * Retrieves the list of names.
     * 
     * @return The list of names.
     */
    List<String> getNameList();
    
    /**
     * Finds an element by its name.
     * 
     * @param name The name of the element to find.
     * @return The found element.
     */
    DataAccessElement findElementByName(String name);
}
