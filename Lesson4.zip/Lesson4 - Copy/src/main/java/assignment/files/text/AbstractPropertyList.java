package assignment.files.text;
import java.util.ArrayList;
import java.util.Properties;

public abstract class AbstractPropertyList {
    protected String fileName;
    protected Properties properties;
    protected ArrayList<String> propertyList;

    public AbstractPropertyList(String fileName) {
        this.fileName = fileName;
        this.properties = new Properties();
        this.propertyList = new ArrayList<>();
    }

    public abstract void addValueToPropertyList(String name);

    public abstract void extractProperties();

    public abstract Properties getProperties();

    public abstract void readFile(boolean isXml);

    @Override
    public abstract String toString();

    public abstract void updateProperties();

    public abstract void updatePropertyList();

    public abstract void setProperties(Properties properties);

    public abstract void setPropertyList(ArrayList<String> propertyList);
}