package assignment.files.xml;

import java.util.List;

public class XmlWriterUtil extends AbstractXmlStaxWriteElementData {
    public XmlWriterUtil() {
        super();
    }

    public void createXmlFromExcelData(List<String> sheetNames, List<String[]> headersList, List<List<String[]>> dataList) {
        // Loop through each sheet
        for (int sheetIndex = 0; sheetIndex < sheetNames.size(); sheetIndex++) {
            String sheetName = sheetNames.get(sheetIndex);
            String[] headers = headersList.get(sheetIndex);
            List<String[]> data = dataList.get(sheetIndex);

            createStartParentNode();
            createNode("SheetName", sheetName);
            createStartChildNode("Data");

            // Write headers
            for (String header : headers) {
                createNode("Header", header);
            }

            // Write data rows
            for (String[] rowData : data) {
                createStartChildNode("Row");
                for (String cellData : rowData) {
                    createNode("Cell", cellData);
                }
                createEndParentNode(); // Close Row
            }

            createEndParentNode(); // Close Data
            createEndParentNode(); // Close Sheet
        }
    }

	@Override
	public void writeFile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createXml(String group) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void formatXML(String xml) {
		// TODO Auto-generated method stub
		
	}
}