/**
 * 
 */
package assignment.files.xml;

/**
 * 
 */
public abstract class AbstractXmlStaxWriteElementData {

	/**
	 * 
	 */
	public AbstractXmlStaxWriteElementData() {
		// TODO Auto-generated constructor stub
	}

}
