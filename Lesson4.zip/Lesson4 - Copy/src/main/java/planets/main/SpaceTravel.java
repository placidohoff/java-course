/**
 * Represents a program for simulating space travel.
 */
package planets.main;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;

import assignment.files.xml.XmlWriterUtil;
import assignment.poi.PoiUtility;
import planets.bodies.PlanetaryBodiesContainer;
import planets.transportation.VehiclesContainer;
import planets.util.AppConfig;
import planets.util.PlanetaryConstants;
import planets.util.PlanetaryDialog;
import planets.util.SpaceCalculate;
import java.util.Date;

// import edu.ccri.assignment.planets.test.dialog.PlanetaryDialog;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Represents a program for simulating space travel.
 */
public class SpaceTravel {

	// private static PlanetaryDialog planetDialog = new PlanetaryDialog("Welcome to
	// the Space Calculator");

	private static PlanetaryDialog planetDialog = new PlanetaryDialog("Welcome to the Space Calculator");

	@SuppressWarnings("unused")
	private static int numberOfIterations = 0;

	// Assign values from the app.properties file to the constants being used:
	private static final String FILE_PATH = AppConfig.getPlanetsExcelSheet();
	private static final String EXPORT_PATH = AppConfig.getOutputFilePath();
	private static final int PLANETS_SHEET_NUM = Integer.parseInt(AppConfig.getPlanetsSheetNumber());
	private static final int VEHICLES_SHEET_NUM = Integer.parseInt(AppConfig.getVehiclesSheetNumber());

	private static final String CONTACT_INFO_FILEPATH_INPUT = AppConfig.getInputContactFileName();

	private static final String CONTACT_INFO_FILEPATH_OUTPUT = AppConfig.getOutputContactFilePath();

	private static List<String[]> listOfPlanetsExcelData;
	private static List<String[]> listOfVehiclesExcelData;
	private static List<String[]> listOfContactInfoData;

	private static List<String> listOfPlanetNames;
	private static List<String> listOfVehicleNames;

	/**
	 * Container for storing planetary bodies.
	 */
	public static PlanetaryBodiesContainer planetaryBodiesContainer;

	/**
	 * Container for storing transportation vehicles.
	 */
	public static VehiclesContainer vehiclesContainer;

	/**
	 * Total travel time for all journeys.
	 */
	public static double totalTravelTime;

	/**
	 * Total wages for all journeys.
	 */
	public static double totalWages;

	/**
	 * Flag indicating whether to continue making journeys.
	 */
	public static boolean isContinue = true;

	/**
	 * Accumulates the results of each journey.
	 */
	public static StringBuilder journeyResults = new StringBuilder("");

	/**
	 * Number of iterations.
	 */
	public static int numberOfItterations = 0;

	/**
	 * List to store the results of all journeys.
	 */
	@SuppressWarnings("unchecked")
	public static List<String[]> listOfTotalResults = new ArrayList();

	/**
	 * Results of a single journey leg.
	 */
	public static List<String> journeyLegResults;

	/**
	 * Headers for the Excel table that will hold information about the user's
	 * journey.
	 */
	public static String[] headersForJourneyDetailsExcelTable = { "Journey Leg", "Transportation Vehicle",
			"Starting Planet",
			"Destination Planet", "Travel Time", "Total Salary Expenses", "Salary per Crew Member", "Total Food Cost",
			"Food Cost per Crew Member" };

	/**
	 * Headers for the Excel table that will hold information about the developer's
	 * contact information.
	 */
	public static String[] headersForContactInfoExcelTable = { "Assignment", "First Name", "Last Name",
			"Student ID", "Email", "Date", "Comments" };

	public static List<String[]> headersForExcelExport;

	private static final Logger logger = LogManager.getLogger(SpaceTravel.class);

	public static String[] resultsOfLeg;
	
	public static String accuracy;
	
	public static boolean isAccuracy;
	
	

	/**
	 * Main method to start the space travel simulation program.
	 *
	 * @param args Command-line arguments.
	 */
	public static void main(String[] args) {
		
		try {
			PlanetaryConstants.CreateInstance(true);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		listOfPlanetsExcelData = PoiUtility.getData(FILE_PATH, PLANETS_SHEET_NUM);
		listOfVehiclesExcelData = PoiUtility.getData(FILE_PATH, VEHICLES_SHEET_NUM);
		try {
			listOfContactInfoData = PoiUtility.getDataContactDataFromXML(CONTACT_INFO_FILEPATH_INPUT);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			logger.error("Error extracting contact info: ", e.getMessage());

		}

		System.out.println(listOfContactInfoData.toString());

		planetaryBodiesContainer = new PlanetaryBodiesContainer(listOfPlanetsExcelData);
		vehiclesContainer = new VehiclesContainer(listOfVehiclesExcelData);

		listOfPlanetNames = planetaryBodiesContainer.getNameList();
		listOfVehicleNames = vehiclesContainer.getNameList();

		String[] arrayPlanetNames = new String[listOfPlanetNames.size()];
		listOfPlanetNames.toArray(arrayPlanetNames);

		String[] arrayVehicleNames = new String[listOfVehicleNames.size()];
		listOfVehicleNames.toArray(arrayVehicleNames);

		//Assign configurations for the dialog
		planetDialog.setUseStartingPlanet();
		planetDialog.setUseDestinationPlanet();
		planetDialog.setUseTransporationVehicle();
		planetDialog.setUseConversionRate();
		planetDialog.setUseTravelDate();
		planetDialog.setUseAccuracy();
		
		

		// CREATE THE NEW EXCEL FROM CONTACT INFO:
		// PoiUtility.writeNewContactFile(CONTACT_INFO_FILEPATH_OUTPUT);

		while (isContinue) {
			numberOfIterations++;
			journeyLegResults = new ArrayList<String>();

			planetDialog.showMultiEditDialog(arrayPlanetNames, arrayVehicleNames);
			String startingPlanet = planetDialog.getStartingPlanetName();
			String destinationPlanet = planetDialog.getDestinationPlanetName();
			String transportationVehicle = planetDialog.getTransportationVechicleName();
			Date departureDate = planetDialog.getTravelDate();
			
			//Get Accuracy, pass to PlanetaryConstants
			//CAN BE PUT INTO ITS OWN FUNCTION: SetAccuracy(planetDialog.getAccuracty()) and given javadoc comments
			accuracy = planetDialog.getAccuracy();
			isAccuracy = false;
			
			if(accuracy == "Precise") {
				isAccuracy = true;
			}else if(accuracy == "Estimate") {
				isAccuracy = false;
			}
			
			//Initialize Singleton for testing purposes:
			try {
				PlanetaryConstants.CreateInstance(isAccuracy);
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//Log planetaryConstants from SpaceCalculate for testing purposes:
			System.out.println(SpaceCalculate.getAccuracy());
			
			
			// Commenting out for now. I would like the instance to be returned from PlanetaryConstants. Perhaps in initialization
			//PlanetaryConstants constants = PlanetaryConstants.getInstance();
			
			
			//COMMENT OUT: THIS FOR QUICK TEST!
//			System.out.println(constants.getAccuracyType()); 
			
			

			// Format for day, month, and year
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");

			double conversionRate = planetDialog.getDollarToEuroConversionRate();

			double travelTimeHours = SpaceCalculate.calculateJourneyHours(startingPlanet, destinationPlanet,
					transportationVehicle);

			Date arrivalDate = SpaceCalculate.determineArrivalDate(departureDate, travelTimeHours);

			System.out.println(arrivalDate.toString());

			String travelTimeString = SpaceCalculate.getTimeFormattedAsString(travelTimeHours);

			String[] expensesArray = SpaceCalculate.calculateJourneyExpenses(transportationVehicle, travelTimeHours,
					conversionRate);

			journeyResults.append("Starting Planet: " + startingPlanet + "\n");
			journeyResults.append("Destination Planet: " + destinationPlanet + "\n");
			journeyResults.append("Transportation Vehicle: " + transportationVehicle + "\n");
			journeyResults.append("\n");
			journeyResults.append("Time:" + "\n");
			journeyResults.append("Travel Time: " + travelTimeString + "\n");
			journeyResults.append("Departure Date: " + dateFormat.format(departureDate) + "\n");
			journeyResults.append("Arrival Date: " + dateFormat.format(arrivalDate) + "\n");
			journeyResults.append("\n");
			journeyResults.append("Expenses:" + "\n");
			journeyResults.append("(USA) Salary per crew member: " + expensesArray[0] + "\n");
			journeyResults.append("(USA) Total Salary Expenses: " + expensesArray[1] + "\n");
			journeyResults.append("(USA) Food Expenses per crew member: " + expensesArray[2] + "\n");
			journeyResults.append("(USA) Total Food Expenses: " + expensesArray[3] + "\n\n");
			journeyResults.append("(UK) Salary per crew member: " + expensesArray[4] + "\n");
			journeyResults.append("(UK) Total Salary Expenses: " + expensesArray[5] + "\n");
			journeyResults.append("(UK) Food Expenses per crew member: " + expensesArray[6] + "\n");
			journeyResults.append("(UK) Total Food Expenses: " + expensesArray[7] + "\n\n");

			journeyResults.append("----------------------------------------------------\n");

			planetDialog.showModalDialog(journeyResults.toString());

			resultsOfLeg = returnArrayOfJourneyLeg(numberOfItterations, startingPlanet, destinationPlanet,
					transportationVehicle, travelTimeString, expensesArray);

			listOfTotalResults.add(resultsOfLeg);

			int choice = JOptionPane.showConfirmDialog(null, "Do you want to make another journey?", "Another Journey",
					JOptionPane.YES_NO_OPTION);
			if (choice != JOptionPane.YES_OPTION) {
				isContinue = false;
			} else {
				planetDialog.setUseDestinationPlanet();
				planetDialog.setStartingPlanetName(destinationPlanet);
				planetDialog.setTransportationVehicleName(transportationVehicle);
				planetDialog.setDestinationPlanetName(null);
				planetDialog.setTravelDate(arrivalDate);
				planetDialog.setUseTravelDate();
			}
		}

		// PoiUtility.createExcelFile(headersForExcelTable, listOfTotalResults,
		// EXPORT_PATH);

		// TODO:
		// PoiUtility.createExcelFile(headersForJourneyDetailsExcelTable,
		// listOfTotalResults, EXPORT_PATH);

		List<String> sheetNames = new ArrayList<>();
		sheetNames.add("Space Journey Details");
		sheetNames.add("Developer's Contact Information");

		List<String[]> headersForExportedExcel = new ArrayList<>();
		headersForExportedExcel.add(headersForJourneyDetailsExcelTable);
		headersForExportedExcel.add(headersForContactInfoExcelTable);

		List<List<String[]>> dataCellsForExportedExcel = new ArrayList<>();
		dataCellsForExportedExcel.add(listOfTotalResults);
		List<String[]> contactInfoArray = returnListOfContactInfo(listOfContactInfoData);
		dataCellsForExportedExcel.add(contactInfoArray);

		// TODO: Will pass different values in order to attach the developer's contact
		// information to the excel file:
		// PoiUtility.createExcelFile(headersForExcelTable, listDataFromContactFile,
		// EXPORT_PATH);

		PoiUtility.createExcelFile(sheetNames, headersForExportedExcel, dataCellsForExportedExcel, EXPORT_PATH);
		
		
	}

	private static String[] returnArrayOfJourneyLeg(int numItterations, String startingPlanet, String destinationPlanet,
			String transportationVehicle, String travelTimeString, String[] expensesArray) {

		String[] resultsArray = new String[9];

		resultsArray[0] = Integer.toString(numItterations + 1);
		resultsArray[1] = transportationVehicle;
		resultsArray[2] = startingPlanet;
		resultsArray[3] = destinationPlanet;
		resultsArray[4] = travelTimeString;
		resultsArray[5] = expensesArray[1];
		resultsArray[6] = expensesArray[0];
		resultsArray[7] = expensesArray[3];
		resultsArray[8] = expensesArray[2];

		return resultsArray;
	}

	private static String[] returnArrayOfContactInfo(List<String[]> contactInfoData) {

		String[] contactInfoArray = new String[6];

		// Assuming contactInfoData contains 6 elements in order

		for (int i = 0; i < 6; i++) {
			contactInfoArray[i] = contactInfoData.get(i)[1];

		}
		return contactInfoArray;
	}

	private static List<String[]> returnListOfContactInfo(List<String[]> contactInfoData) {
		List<String[]> contactInfoList = new ArrayList<>();

		// Assuming contactInfoData contains at least 6 elements
		for (int i = 0; i < 6; i++) {
			if (i < contactInfoData.size() && contactInfoData.get(i) != null && contactInfoData.get(i).length >= 2) {
				String[] contactInfoArray = new String[2];
				contactInfoArray[0] = contactInfoData.get(i)[0]; // Assuming the first element is the key
				contactInfoArray[1] = contactInfoData.get(i)[1]; // Assuming the second element is the value
				contactInfoList.add(contactInfoArray);
			} else {
				// Handle missing or incomplete data
				// You can skip adding this entry or handle it differently based on your
				// requirements
			}
		}

		return contactInfoList;
	}

}
