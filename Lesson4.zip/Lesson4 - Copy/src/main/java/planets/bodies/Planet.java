package planets.bodies;

/**
 * Represents a planet in the solar system.
 */
public class Planet extends PlanetaryBody {
    
    /**
     * Constructs a planet object using the provided array of planet details.
     *
     * @param planetDetails An array containing details of the planet.
     */
    public Planet(String[] planetDetails){
        super(planetDetails);
    }

    /**
     * Retrieves the name of the planet.
     *
     * @return The name of the planet.
     */
    @Override
    public String getElementName() {
        return this.name;
    }

    /**
     * Returns a string representation of the planet.
     *
     * @return A string representation of the planet.
     */
    @Override
    public String toString() {
        return this.getElementName();
    }
    
    /**
     * Calculates and returns the drag coefficient of the planet.
     *
     * @return The drag coefficient of the planet.
     */
    @Override
    public double getDragCoeficient() {
        return 0.1 + (this.albedo * this.orbitalEccentricity);
    }
}
