package planets.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class AppConfig {


	private final static String FILE_PATH = "src/main/resources/edu.ccri.assignment.lesson04/app.properties";
	
	private static Properties properties;
	
	/*
	 * Static block for initialization without having to have an instance:
	 * */
	
	static {
		properties = new Properties();
		
		try {
			properties.load(new FileInputStream(FILE_PATH));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static String getPlanetsExcelSheet() {
		return properties.getProperty("input.file.name");
	}
	
	public static String getContactWorksheetName() {
        return properties.getProperty("output.contact.worksheet.name");
    }
	
	public static String getInputContactFileName() {
        return properties.getProperty("input.contact.file.name");
    }
	
	public static String getOutputContactFilePath() {
		return properties.getProperty("input.contact.file.output.src");
	}
	
	public static String getOutputFilePath() {
		return properties.getProperty("output.file.name.prefix");
	}
	
	public static String getPlanetsSheetNumber() {
		return properties.getProperty("input.file.planets.sheetnumber");
	}
	
	public static String getVehiclesSheetNumber() {
		return properties.getProperty("input.file.vehicles.sheetnumber");
	}
	
	public static String getConstantsFilePath() {
		return properties.getProperty("input.file.name.planetary.constants");
	}
	
	

	

}
