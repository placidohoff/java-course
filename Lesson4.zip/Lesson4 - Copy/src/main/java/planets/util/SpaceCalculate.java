/**
 * Utility class for calculating space travel-related parameters such as estimated time to travel and distance between celestial bodies.
 */
package planets.util;

import planets.bodies.PlanetaryBodiesContainer;
import planets.bodies.PlanetaryBody;
import planets.transportation.TransportationVehicle;
import planets.transportation.VehiclesContainer;

import static java.lang.Math.sqrt;

import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static java.lang.Math.PI;

/**
 * Utility class for calculating space travel-related parameters such as
 * estimated time to travel and distance between celestial bodies.
 * 
 * All constants values are pulled from the PlanetaryConstants Singleton class which is assigned values based on the users's selection of estimated or precise values.
 * 
 */
public class SpaceCalculate {
	
	public static PlanetaryConstants planetaryConstants;

	/**
	 * Represents the number of days in a year.
	 */
	private static final double DAYS_IN_A_YEAR = planetaryConstants.getDaysInYear();

	/**
	 * Represents the number of hours in a day.
	 */
	private static final double HOURS_IN_A_DAY = planetaryConstants.getHoursInDay();

	/**
	 * Represents the conversion factor for kilograms to pounds.
	 */
	private static final double CONVERSION_FACTOR_KILOGRAM_TO_POUNDS = planetaryConstants.getKilogramsToPounds();
  
	/**
	 * Represents the conversion factor for pounds to kilograms.
	 */
	private static final double CONVERSION_FACTOR_POUNDS_TO_KILOGRAM = planetaryConstants.getPoundsToKilograms();

	/**
	 * Represents the conversion factor for kilometers to miles.
	 */
	private static final double CONVERSION_FACTOR_KILOMETERS_TO_MILES = planetaryConstants.getKilometersToMiles();

	/**
	 * Represents the conversion factor for miles to kilometers.
	 */
	private static final double CONVERSION_FACTOR_MILES_TO_KILOMETER = planetaryConstants.getMilesToKilometers();

	/**
	 * Represents the number of seconds in a year.
	 */
	private static final double SECONDS_PER_YEAR = 86400;

	/**
	 * Represents the velocity currently in use.
	 */
	private static double velocityInUse = 0;

	/**
	 * Represents the orbital velocity.
	 */
	private static double orbitalVelocity;

	/**
	 * Represents the gravity assist.
	 */
	public static double gravityAssist;

	/**
	 * Represents the starting planet.
	 */
	private static PlanetaryBody startingPlanet;

	/**
	 * Represents the destination planet.
	 */
	private static PlanetaryBody destinationPlanet;

	/**
	 * Represents the transportation vehicle.
	 */
	private static TransportationVehicle transportationVehicle;

	/**
	 * Represents the current velocity of the vehicle.
	 */
	private static double currentVehicleVelocity = 0;

	/**
	 * Represents the travel time in hours.
	 */
	private static double travelTimeHours;

	/**
	 * Represents the distance between planetary bodies.
	 */
	private static double distanceBetweenPlanetaryBodies;

	public static double numberOfCrewMembers;
	public static double hourlySalaryPerCrewMember;
	public static double totalTripDurationDays;
	public static double salaryPerCrewMember;

	public static double foodCostPerMealPerCrewMember;
	public static double mealsPerDay;
	
	
	
	/**
	 * Static Initializer that will get an instance of PlanetaryConstants which was created with the appropriate boolean from the man.SpaceTravel.java
	 */
	static {
		
		planetaryConstants = PlanetaryConstants.getInstance();
		
	}
	
	//METHOD USED TO RETURN THE NAME OF THE PLANETARYCONSTANTS TO TEST IF ACCURATE OR ESTIMATE:
	public static String getAccuracy() {
		return planetaryConstants.getAccuracyType();
	}
	
	
	

	/**
	 * Updates the orbital velocity based on the distance from the sun and the year
	 * length of a celestial body.
	 *
	 * @param objDistanceFromSun The distance of the celestial body from the sun.
	 * @param objYearLength      The year length of the celestial body.
	 * @return The updated orbital velocity.
	 */
	public static double findOrbitalVelocity(double objDistanceFromSun, double objYearLength) {
		double ds = objDistanceFromSun;
		double op = objYearLength;

		return (3.6 * sqrt((2 * PI * ds * 1000) / (op * DAYS_IN_A_YEAR)));
	}

	/**
	 * Applies the gravity assist effect to the orbital velocity.
	 *
	 * @return The updated orbital velocity after applying the gravity assist.
	 */
	public static double applyGravityAssist() {
		return (2 * orbitalVelocity);
	}

	/**
	 * Calculates the estimated journey hours between two celestial bodies using a
	 * specified transportation vehicle.
	 *
	 * @param startingPlanetName        The name of the starting celestial body.
	 * @param destinationPlanetName     The name of the destination celestial body.
	 * @param transportationVehicleName The name of the transportation vehicle to be
	 *                                  used.
	 * @return The estimated journey hours.
	 */
	public static double calculateJourneyHours(String startingPlanetName, String destinationPlanetName,
			String transportationVehicleName) {
		// Necessary variables
		PlanetaryBody originPlanetaryBody = (PlanetaryBody) planets.main.SpaceTravel.planetaryBodiesContainer
				.findElementByName(startingPlanetName);

		PlanetaryBody destinationPlanetaryBody = (PlanetaryBody) planets.main.SpaceTravel.planetaryBodiesContainer
				.findElementByName(destinationPlanetName);

		TransportationVehicle transportationVehicle = (TransportationVehicle) planets.main.SpaceTravel.vehiclesContainer
				.findElementByName(transportationVehicleName);

		distanceBetweenPlanetaryBodies = findDistanceBetween(originPlanetaryBody, destinationPlanetaryBody);

		// If the current velocity has not been set yet, set it to be the max speed of
		// the vehicle
		if (currentVehicleVelocity == 0) {
			currentVehicleVelocity = transportationVehicle.getMaxSpeed();
		}

		// Obtain Orbital velocity of the origin planet as this is a component of the
		// gravity assist which affects the vehicle's speed:
		// @param: distanceFromTheSun, yearLength
		orbitalVelocity = findOrbitalVelocity(originPlanetaryBody.getAvgDistanceFromTheSun(),
				originPlanetaryBody.getDaysPerYear());

		currentVehicleVelocity += findGravityAssist() - originPlanetaryBody.getDragCoeficient();

		currentVehicleVelocity -= transportationVehicle.getDragCoeficient();

		// May have to convert km/hr to mph
		travelTimeHours = findTravelTime(distanceBetweenPlanetaryBodies);

		return travelTimeHours;
	}

	/**
	 * Finds the gravity assist factor.
	 *
	 * @return The gravity assist factor.
	 */
	public static double findGravityAssist() {
		return 2 * orbitalVelocity;
	}

	/**
	 * Finds the distance between two celestial bodies.
	 *
	 * @param start  The starting celestial body.
	 * @param finish The destination celestial body.
	 * @return The distance between the two celestial bodies.
	 */
	public static double findDistanceBetween(PlanetaryBody start, PlanetaryBody finish) {
		return Math.abs(start.getAvgDistanceFromTheSun() - finish.getAvgDistanceFromTheSun());
	}

	/**
	 * Finds the estimated travel time between two celestial bodies.
	 *
	 * @param distance The distance between the celestial bodies.
	 * @return The estimated travel time.
	 */
	public static double findTravelTime(double distance) {
		// May have to convert kmph to mph first.
		// Convert kilometers-per-hour to miles-per-hour
		distance *= CONVERSION_FACTOR_KILOMETERS_TO_MILES;
		return (distance / currentVehicleVelocity);
	}

	// GETTERS FOR THE CONSTANTS:

	/**
	 * Retrieves the number of days in a year.
	 *
	 * @return The number of days in a year.
	 */
	public static double getDaysPerYear() {
		return DAYS_IN_A_YEAR;
	}

	/**
	 * Retrieves the number of hours in a day.
	 *
	 * @return The number of hours in a day.
	 */
	public static double getHoursPerDay() {
		return HOURS_IN_A_DAY;
	}

	/**
	 * Retrieves the conversion factor for converting kilograms to pounds.
	 *
	 * @return The conversion factor for kilograms to pounds.
	 */
	public static double getConversionKilogramsToPounds() {
		return CONVERSION_FACTOR_KILOGRAM_TO_POUNDS;
	}

	/**
	 * Retrieves the conversion factor for converting pounds to kilograms.
	 *
	 * @return The conversion factor for pounds to kilograms.
	 */
	public static double getConversionPoundsToKilograms() {
		return CONVERSION_FACTOR_POUNDS_TO_KILOGRAM;
	}

	/**
	 * Retrieves the conversion factor for converting kilometers to miles.
	 *
	 * @return The conversion factor for kilometers to miles.
	 */
	public static double getConversionKilometersToMiles() {
		return CONVERSION_FACTOR_KILOMETERS_TO_MILES;
	}

	/**
	 * Retrieves the conversion factor for converting miles to kilometers.
	 *
	 * @return The conversion factor for miles to kilometers.
	 */
	public static double getConversionMilesToKilometer() {
		return CONVERSION_FACTOR_MILES_TO_KILOMETER;
	}
	
	

	/**
	 * Formats the estimated travel time as a string.
	 *
	 * @param estimatedTravelTime The estimated travel time.
	 * @return The formatted estimated travel time.
	 */
	public static String getTimeFormattedAsString(double estimatedTravelTime) {
        StringBuilder message = new StringBuilder("");
        final double HOURS_PER_YEAR = 8760;
        final double HOURS_PER_DAY = 24;

        if (estimatedTravelTime > HOURS_PER_YEAR) {
            double years = estimatedTravelTime / HOURS_PER_YEAR;
            String formattedTime = String.format("%.1f years", years);
            message.append(formattedTime);
        } else if (estimatedTravelTime > HOURS_PER_DAY) {
            double days = estimatedTravelTime / HOURS_PER_DAY;
            String formattedTime = String.format("%.1f days", days);
            message.append(formattedTime);
        } else {
            String formattedTime = String.format("%.1f hours", estimatedTravelTime);
            message.append(formattedTime);
        }

        return message.toString();
	}

	/**
	 * Calculates the expenses incurred during a space journey.
	 *
	 * @param vehicleName    The name of the transportation vehicle.
	 * @param travelHours    The duration of the journey in hours.
	 * @param conversionRate The currency conversion rate.
	 * @return An array containing the calculated expenses in different currencies
	 *         and formats.
	 */
	public static String[] calculateJourneyExpenses(String vehicleName, double travelHours, double conversionRate) {
		// Get the vehicle object from the name passed in.
		TransportationVehicle vehicleInUse = (TransportationVehicle) planets.main.SpaceTravel.vehiclesContainer
				.findElementByName(vehicleName);

		double totalAnnualEquitableCrewSalary = calculateSalaryExpenses(vehicleInUse, travelHours);

		double totalCrewSalaryEuros = totalAnnualEquitableCrewSalary * conversionRate;
		double totalCrewMemberSalaryEuros = salaryPerCrewMember * conversionRate;

		// Format the total annual equitable crew salary
		NumberFormat currencyFormatterUSA = NumberFormat.getCurrencyInstance(Locale.US);
		NumberFormat currencyFormatterUK = NumberFormat.getCurrencyInstance(Locale.UK);

		// DOLLAR FORMAT FOR SALARY
		String formattedTotalAnnualEquitableCrewSalary_USA = currencyFormatterUSA
				.format(totalAnnualEquitableCrewSalary);
		String formattedSalaryPerCrewMember_USA = currencyFormatterUSA.format(salaryPerCrewMember);

		// EURO FORMAT FOR SALARY
		String formattedTotalAnnualEquitableCrewSalary_UK = currencyFormatterUK.format(totalAnnualEquitableCrewSalary);
		String formattedSalaryPerCrewMember_UK = currencyFormatterUK.format(salaryPerCrewMember);

		// FOOD COSTS CALCULATIONS:
		double totalAnnualCrewFoodCosts = calculateFoodExpenses(vehicleInUse);

		double foodCostPerMealPerCrewMemberInEuros = foodCostPerMealPerCrewMember * conversionRate;
		double totalAnnualCrewFoodCostsInEuros = totalAnnualCrewFoodCosts * conversionRate;

		// DOLLAR FORMAT FOR FOOD COSTS:
		String formattedTotalAnnualCrewFoodCostsUSA = currencyFormatterUSA.format(totalAnnualCrewFoodCosts);
		String formattedMealCostPerCrew = currencyFormatterUSA.format(foodCostPerMealPerCrewMember);

		// EURO FORMAT FOR FOOD COSTS:
		String formattedTotalAnnualCrewFoodCostsUK = currencyFormatterUK.format(totalAnnualCrewFoodCostsInEuros);
		String formattedMealCostPerCrewUK = currencyFormatterUK.format(foodCostPerMealPerCrewMemberInEuros);

		return new String[] { formattedSalaryPerCrewMember_USA, formattedTotalAnnualEquitableCrewSalary_USA,
				formattedMealCostPerCrew, formattedTotalAnnualCrewFoodCostsUSA, formattedSalaryPerCrewMember_UK,
				formattedTotalAnnualEquitableCrewSalary_UK, formattedMealCostPerCrewUK,
				formattedTotalAnnualCrewFoodCostsUK };
	}

	public static double calculateSalaryExpenses(TransportationVehicle vehicleInUse, double travelHours) {
		numberOfCrewMembers = vehicleInUse.getNumberOfCrew();
		hourlySalaryPerCrewMember = vehicleInUse.getHourlySalaryPerCrewMember();
		totalTripDurationDays = travelHours / HOURS_IN_A_DAY;

		/** Ensuring employee salary does not exceed $1,000,000 */

		salaryPerCrewMember = hourlySalaryPerCrewMember * totalTripDurationDays
				* vehicleInUse.getPayHoursPerDay();

		if (salaryPerCrewMember > 1000000) {
			salaryPerCrewMember = 1000000;
		}

		return numberOfCrewMembers * salaryPerCrewMember;

	}

	public static double calculateFoodExpenses(TransportationVehicle vehicleInUse) {
		foodCostPerMealPerCrewMember = vehicleInUse.getDailyFoodCostPerCrewMember();
		mealsPerDay = vehicleInUse.getMealsPerDay();

		return numberOfCrewMembers * foodCostPerMealPerCrewMember * totalTripDurationDays
				* mealsPerDay;
	}

	/**
	 * Determines the arrival date based on the departure date and time to travel in
	 * hours.
	 *
	 * @param departureDate The departure date.
	 * @param travelHours   The travel time in hours.
	 * @return The arrival date.
	 */
	public static Date determineArrivalDate(Date departureDate, double travelHours) {
		// Create a Calendar instance and set it to the departure time
		Calendar arrivalCalendar = Calendar.getInstance();
		arrivalCalendar.setTime(departureDate);

		// Add the travel hours to the calendar
		arrivalCalendar.add(Calendar.HOUR_OF_DAY, (int) travelHours);

		// Create a new Date object from the modified Calendar
		return arrivalCalendar.getTime();
	}
}
