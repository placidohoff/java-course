package planets.transportation;

/**
 * Represents an aircraft for transportation.
 */
public class AirCraft extends TransportationVehicle {

	/** Drag coefficient for aircraft */
	public static final double DRAG_COEFICIENT = 0.0102;

	/** Meals per day for aircraft */
	public static final double MEALS_PER_DAY = 3.5;

	/** Pay hours per day for aircraft */
	public static final double PAY_HOURS_PER_DAY = 24;

	/**
	 * Constructs an aircraft object using the provided array of aircraft details.
	 *
	 * @param strings An array containing details of the aircraft.
	 */
	public AirCraft(String[] strings) {
		super(strings);
	}

	/**
	 * Retrieves the daily salary per crew member for the aircraft.
	 *
	 * @return The daily salary per crew member.
	 */
	@Override
	public double getDailySalaryPerCrewMember() {
		return 0; // No daily salary for aircraft crew
	}

	/**
	 * Returns a string representation of the aircraft.
	 *
	 * @return A string representation of the aircraft.
	 */
	@Override
	public String toString() {
		return this.getVehicleName();
	}

	/**
	 * Retrieves the drag coefficient of the aircraft.
	 *
	 * @return The drag coefficient of the aircraft.
	 */
	@Override
	public double getDragCoeficient() {
		return DRAG_COEFICIENT;
	}

	/**
	 * Retrieves the meals per day for the aircraft crew.
	 *
	 * @return The meals per day for the aircraft crew.
	 */
	@Override
	public double getMealsPerDay() {
		return MEALS_PER_DAY;
	}

	/**
	 * Retrieves the pay hours per day for the aircraft crew.
	 *
	 * @return The pay hours per day for the aircraft crew.
	 */
	@Override
	public double getPayHoursPerDay() {
		return PAY_HOURS_PER_DAY;
	}

	/**
	 * Retrieves the name of the aircraft.
	 *
	 * @return The name of the aircraft.
	 */
	@Override
	public String getElementName() {
		return this.getVehicleName();
	}

}
