package planets.transportation;

import assignment.data.CrewExpenses;
import assignment.data.DataAccessElement;

/**
 * Represents a transportation vehicle used for interplanetary travel.
 */
public abstract class TransportationVehicle implements CrewExpenses, DataAccessElement {
    
    /** The maximum weight capacity of the vehicle. */
    public double maximumWeight;
    
    /** The volume capacity of the vehicle. */
    public double volume;
    
    /** The cost to build the vehicle. */
    public double costToBuild;
    
    /** The maximum speed of the vehicle. */
    public double maxSpeed;
    
    /** The number of crew members required to operate the vehicle. */
    public double numberOfCrew;
    
    /** Description of metric measurements used for the vehicle. */
    public String metricMeasurementsDescription;
    
    /** The cost of meals per crew member per day. */
    public double mealCostPerCrewMember;
    
    /** The hourly salary per crew member. */
    public double hourlySalaryPerCrewMember;
    
    /** A description of the vehicle. */
    public String description;
    
    /** An interesting fact about the vehicle. */
    public String interestingFact;
    
    /** Additional notes about the vehicle. */
    public String notes;
    
    /** The name of the vehicle. */
    public String vehicleName;

    /**
     * Constructs a transportation vehicle object using the provided array of vehicle details.
     *
     * @param excelDataRow An array containing details of the vehicle.
     */
    public TransportationVehicle(String[] excelDataRow)  {
        this.vehicleName = excelDataRow[1];
        this.maximumWeight = Double.parseDouble(excelDataRow[3]);
        this.volume = Double.parseDouble(excelDataRow[4]);
        this.costToBuild = Double.parseDouble(excelDataRow[5]);
        this.maxSpeed = Double.parseDouble(excelDataRow[6]);
        this.numberOfCrew = Double.parseDouble(excelDataRow[7]);
        this.metricMeasurementsDescription = excelDataRow[8];
        this.mealCostPerCrewMember = Double.parseDouble(excelDataRow[9]);
        this.hourlySalaryPerCrewMember = Double.parseDouble(excelDataRow[10]);
        this.description = excelDataRow[11];
        this.interestingFact = excelDataRow[12];
        this.notes = excelDataRow[13];
    }

    /**
     * Retrieves the daily food cost per crew member.
     *
     * @return The daily food cost per crew member.
     */
    @Override
    public double getDailyFoodCostPerCrewMember() {
        return this.mealCostPerCrewMember;
    }

    /**
     * Retrieves the daily salary per crew member.
     *
     * @return The daily salary per crew member.
     */
    @Override
    public abstract double getDailySalaryPerCrewMember();

    /**
     * Calculates and returns the drag coefficient of the vehicle.
     *
     * @return The drag coefficient of the vehicle.
     */
    public abstract double getDragCoeficient();

    /**
     * Returns the number of pay hours per day.
     *
     * @return The number of pay hours per day.
     */
    public abstract double getPayHoursPerDay();

    /**
     * Returns the number of meals per day.
     *
     * @return The number of meals per day.
     */
    public abstract double getMealsPerDay();

    /**
     * Returns a string representation of the vehicle.
     *
     * @return A string representation of the vehicle.
     */
    @Override
    public abstract String toString();

    /**
     * Retrieves the maximum weight capacity of the vehicle.
     *
     * @return The maximum weight capacity of the vehicle.
     */
    public double getMaximumWeight() {
        return maximumWeight;
    }

    /**
     * Retrieves the volume capacity of the vehicle.
     *
     * @return The volume capacity of the vehicle.
     */
    public double getVolume() {
        return volume;
    }

    /**
     * Retrieves the cost to build the vehicle.
     *
     * @return The cost to build the vehicle.
     */
    public double getCostToBuild() {
        return costToBuild;
    }

    /**
     * Retrieves the maximum speed of the vehicle.
     *
     * @return The maximum speed of the vehicle.
     */
    public double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * Retrieves the number of crew members required to operate the vehicle.
     *
     * @return The number of crew members required to operate the vehicle.
     */
    public double getNumberOfCrew() {
        return numberOfCrew;
    }

    /**
     * Retrieves the description of metric measurements used for the vehicle.
     *
     * @return The description of metric measurements used for the vehicle.
     */
    public String getMetricMeasurementsDescription() {
        return metricMeasurementsDescription;
    }

    /**
     * Retrieves the meal cost per crew member per day.
     *
     * @return The meal cost per crew member per day.
     */
    public double getMealCostPerCrewMember() {
        return mealCostPerCrewMember;
    }

    /**
     * Retrieves the hourly salary per crew member.
     *
     * @return The hourly salary per crew member.
     */
    public double getHourlySalaryPerCrewMember() {
        return hourlySalaryPerCrewMember;
    }

    /**
     * Retrieves the description of the vehicle.
     *
     * @return The description of the vehicle.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Retrieves an interesting fact about the vehicle.
     *
     * @return An interesting fact about the vehicle.
     */
    public String getInterestingFact() {
        return interestingFact;
    }

    /**
     * Retrieves additional notes about the vehicle.
     *
     * @return Additional notes about the vehicle.
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Retrieves the name of the vehicle.
     *
     * @return The name of the vehicle.
     */
    public String getVehicleName() {
        return this.vehicleName;
    }
}
