package planets.transportation;

import planets.bodies.DwarfPlanet;
import planets.bodies.Moon;
import planets.bodies.Planet;
import planets.bodies.PlanetaryBody;

public class TransportationVehicleFactory {

	public TransportationVehicle createTransportationVehicle(String[] data) {
        switch (data[2]) {
            case "Aircraft":
            case "Spacecraft":
            case "Drone":
            case "Helicopter":
            case "Starship":
                return new AirCraft(data);
            case "Boat":
            case "Cruise Ship":
            case "Submarine":
                return new SeaCraft(data);
            default:
                return new LandCraft(data);
        }
    }

}
