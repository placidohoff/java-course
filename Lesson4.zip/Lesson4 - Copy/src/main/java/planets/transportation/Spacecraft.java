package planets.transportation;

/**
 * Represents a spacecraft for transportation.
 */
public class Spacecraft extends TransportationVehicle {

	/**
	 * Constructs a spacecraft object using the provided array of spacecraft
	 * details.
	 *
	 * @param excelDataRow An array containing details of the spacecraft.
	 */
	public Spacecraft(String[] excelDataRow) {
		super(excelDataRow);
	}

	/**
	 * Retrieves the daily salary per crew member for the spacecraft.
	 *
	 * @return The daily salary per crew member.
	 */
	@Override
	public double getDailySalaryPerCrewMember() {
		return 0; // No daily salary for spacecraft crew
	}

	/**
	 * Returns a string representation of the spacecraft.
	 *
	 * @return A string representation of the spacecraft.
	 */
	@Override
	public String toString() {
		return this.getVehicleName();
	}

	/**
	 * Retrieves the name of the spacecraft.
	 *
	 * @return The name of the spacecraft.
	 */
	@Override
	public String getElementName() {
		return this.getVehicleName();
	}

	/**
	 * Calculates and returns the drag coefficient of the spacecraft.
	 *
	 * @return The drag coefficient of the spacecraft.
	 */
	@Override
	public double getDragCoeficient() {
		return 0; // Drag coefficient for spacecraft (may vary)
	}

	/**
	 * Retrieves the pay hours per day for the spacecraft crew.
	 *
	 * @return The pay hours per day for the spacecraft crew.
	 */
	@Override
	public double getPayHoursPerDay() {
		return 24; // Crew works around the clock
	}

	/**
	 * Retrieves the number of meals per day for the spacecraft crew.
	 *
	 * @return The number of meals per day for the spacecraft crew.
	 */
	@Override
	public double getMealsPerDay() {
		return 3.5; // Crew typically gets multiple meals per day
	}

}
